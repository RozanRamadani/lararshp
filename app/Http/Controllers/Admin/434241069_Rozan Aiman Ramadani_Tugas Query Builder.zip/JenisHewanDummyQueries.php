<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

/**
 * Dummy helper controller with SQL and Query Builder examples.
 *
 * Temporary file to demonstrate raw SQL and Query Builder usage
 * for the `jenis_hewan`, `ras_hewan` and `pet` tables.
 */
class JenisHewanDummyQueries extends Controller
{
    /**
     * Return raw SQL strings for reference.
     *
     * @return array
     */
    public function rawSql(): array
    {
        $sql1 = "SELECT j.*, (SELECT COUNT(*) FROM pet JOIN ras_hewan ON pet.idras_hewan = ras_hewan.idras_hewan WHERE ras_hewan.idjenis_hewan = j.idjenis_hewan) AS pets_count FROM jenis_hewan AS j";

        $sql2 = "SELECT r.*, COUNT(p.idpet) AS pets_count FROM ras_hewan AS r LEFT JOIN pet AS p ON p.idras_hewan = r.idras_hewan WHERE r.idjenis_hewan = ? GROUP BY r.idras_hewan";

        return [
            'jenis_with_pets_subquery' => $sql1,
            'ras_per_jenis_grouped' => $sql2,
        ];
    }

    /**
     * Example using DB::select for raw SQL (returns array of stdClass).
     *
     * @return array
     */
    public function exampleRawSelect()
    {
        $sql = $this->rawSql()['jenis_with_pets_subquery'];
        return DB::select($sql);
    }

    /**
     * Example using Query Builder: daftar jenis_hewan dengan jumlah pets (JOIN + GROUP BY)
     *
     * @return \Illuminate\Support\Collection
     */
    public function exampleQueryBuilderJenis()
    {
        return DB::table('jenis_hewan as j')
            ->leftJoin('ras_hewan as r', 'r.idjenis_hewan', '=', 'j.idjenis_hewan')
            ->leftJoin('pet as p', 'p.idras_hewan', '=', 'r.idras_hewan')
            ->select('j.*', DB::raw('COUNT(p.idpet) as pets_count'))
            ->groupBy('j.idjenis_hewan')
            ->get();
    }

    /**
     * Example Query Builder: daftar ras_hewan untuk satu jenis beserta jumlah pets per ras.
     *
     * @param  int  $idjenis
     * @return \Illuminate\Support\Collection
     */
    public function exampleQueryBuilderRasPerJenis($idjenis)
    {
        return DB::table('ras_hewan as r')
            ->leftJoin('pet as p', 'p.idras_hewan', '=', 'r.idras_hewan')
            ->where('r.idjenis_hewan', $idjenis)
            ->select('r.*', DB::raw('COUNT(p.idpet) as pets_count'))
            ->groupBy('r.idras_hewan')
            ->get();
    }
}
